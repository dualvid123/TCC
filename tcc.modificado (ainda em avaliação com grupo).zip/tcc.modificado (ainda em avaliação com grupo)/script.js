/* =========================================================
   DARK MODE
========================================================= */
function toggleDark() {
    document.body.classList.toggle('dark');
    localStorage.setItem('tema', document.body.classList.contains('dark') ? 'dark' : 'light');
}

(function aplicarTema() {
    if (localStorage.getItem('tema') === 'dark') {
        document.body.classList.add('dark');
    }
})();

/* =========================================================
   MENU HAMBÚRGUER
========================================================= */
function toggleMenu() {
    const menu = document.getElementById('menu');
    const overlay = document.getElementById('menuOverlay');
    const aberto = menu.classList.toggle('ativo');
    if (overlay) overlay.classList.toggle('ativo', aberto);
    document.body.style.overflow = aberto ? 'hidden' : '';
}

document.addEventListener('DOMContentLoaded', function () {
    /* Cria overlay do menu mobile */
    const overlay = document.createElement('div');
    overlay.id = 'menuOverlay';
    overlay.className = 'menu-overlay';
    overlay.addEventListener('click', toggleMenu);
    document.body.appendChild(overlay);

    /* Fecha menu ao clicar em link */
    document.querySelectorAll('.nav-links a').forEach(function (link) {
        link.addEventListener('click', function () {
            const menu = document.getElementById('menu');
            const ov = document.getElementById('menuOverlay');
            if (menu.classList.contains('ativo')) {
                menu.classList.remove('ativo');
                if (ov) ov.classList.remove('ativo');
                document.body.style.overflow = '';
            }
        });
    });
});

/* =========================================================
   SEARCH TOGGLE
========================================================= */
function toggleSearch() {
    const box = document.getElementById('searchBox');
    box.classList.toggle('aberto');
    if (box.classList.contains('aberto')) {
        const input = document.getElementById('buscaPlantas');
        if (input) setTimeout(function () { input.focus(); }, 320);
    } else {
        const res = document.getElementById('resultadosBusca');
        if (res) res.classList.remove('aberto');
    }
}

/* =========================================================
   BUSCA INTELIGENTE
========================================================= */
document.addEventListener('DOMContentLoaded', function () {
    const campo = document.getElementById('buscaPlantas');
    const resultados = document.getElementById('resultadosBusca');
    if (!campo || !resultados) return;

    function normalizar(t) {
        return String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
    }

    function criarIndice() {
        var itens = [];
        var vistos = new Set();

        /* Cards centrais */
        if (typeof dadosDosCards !== 'undefined') {
            dadosDosCards.forEach(function (d) {
                var chave = normalizar(d.titulo);
                if (!vistos.has(chave)) {
                    vistos.add(chave);
                    itens.push({ nome: d.titulo, categoria: 'Destaque', palavras: [d.titulo, d.descricao].join(' ') });
                }
            });
        }

        /* Cards do carrossel */
        document.querySelectorAll('.carousel-card').forEach(function (card) {
            var h3 = card.querySelector('h3');
            var p = card.querySelector('p');
            var rev = card.querySelector('.reviews');
            var area = card.closest('.carousel-area-com-setas');
            var categoria = area ? (area.previousElementSibling && area.previousElementSibling.querySelector('h2') ? area.previousElementSibling.querySelector('h2').textContent.trim() : '') : '';
            var nome = h3 ? h3.textContent.trim() : 'Planta';
            var chave = normalizar(nome + categoria);

            if (!vistos.has(chave)) {
                vistos.add(chave);
                itens.push({
                    nome: nome,
                    categoria: categoria || 'Plantas',
                    palavras: [nome, categoria, p ? p.textContent : '', rev ? rev.textContent : ''].join(' '),
                    elemento: card
                });
            }
        });

        return itens.sort(function (a, b) {
            return a.nome.localeCompare(b.nome, 'pt-BR', { sensitivity: 'base' });
        });
    }

    function renderizar() {
        var termo = normalizar(campo.value.trim());
        resultados.innerHTML = '';

        if (!termo) {
            resultados.classList.remove('aberto');
            return;
        }

        var encontrados = criarIndice().filter(function (item) {
            return normalizar(item.palavras).includes(termo);
        });

        if (!encontrados.length) {
            resultados.innerHTML = '<div class="busca-sem-resultados">Nenhuma planta encontrada.</div>';
            resultados.classList.add('aberto');
            return;
        }

        encontrados.forEach(function (item) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'resultado-busca-planta';
            btn.innerHTML = '<span><strong>' + item.nome + '</strong><small>' + item.categoria + '</small></span>';
            btn.addEventListener('click', function () {
                resultados.classList.remove('aberto');
                if (item.elemento) {
                    item.elemento.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    item.elemento.style.outline = '3px solid #5cb82a';
                    item.elemento.style.borderRadius = '12px';
                    setTimeout(function () { item.elemento.style.outline = ''; }, 1800);
                }
            });
            resultados.appendChild(btn);
        });

        resultados.classList.add('aberto');
    }

    campo.addEventListener('input', renderizar);
    campo.addEventListener('focus', function () { if (campo.value.trim()) renderizar(); });

    campo.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
            var primeiro = resultados.querySelector('.resultado-busca-planta');
            if (primeiro) { e.preventDefault(); primeiro.click(); }
        }
        if (e.key === 'Escape') { resultados.classList.remove('aberto'); campo.blur(); }
    });

    document.addEventListener('click', function (e) {
        if (!campo.closest('.searchBox').contains(e.target)) {
            resultados.classList.remove('aberto');
        }
    });
});

/* =========================================================
   CAROUSEL
========================================================= */
function moverCarrossel(botao, direcao) {
    var area = botao.closest('.carousel-area-com-setas');
    var container = area.querySelector('.carousel-container');
    var card = container.querySelector('.carousel-card');
    if (!card) return;
    var dist = card.offsetWidth + 20;
    container.scrollBy({ left: direcao * dist, behavior: 'smooth' });
}

/* =========================================================
   CATEGORY FILTER
========================================================= */
function filtrarCategoria(botao, categoria) {
    document.querySelectorAll('.botao-filtro-central').forEach(function (b) {
        b.classList.remove('ativo');
    });
    botao.classList.add('ativo');

    document.querySelectorAll('.carousel-card').forEach(function (card) {
        if (categoria === 'all') {
            card.style.display = '';
        } else {
            var cats = card.getAttribute('data-categoria') || '';
            card.style.display = cats.includes(categoria) ? '' : 'none';
        }
    });

    /* Mostra/oculta seções inteiras */
    document.querySelectorAll('.carousel-area-com-setas').forEach(function (area) {
        if (categoria === 'all') {
            area.style.display = '';
            var header = area.previousElementSibling;
            if (header && header.classList.contains('cabecalho-categoria-plantas')) header.style.display = '';
        } else {
            var cat = area.getAttribute('data-categoria') || '';
            var visivel = cat === categoria || categoria === 'indoor';
            area.style.display = visivel ? '' : 'none';
            var hdr = area.previousElementSibling;
            if (hdr && hdr.classList.contains('cabecalho-categoria-plantas')) hdr.style.display = visivel ? '' : 'none';
        }
    });
}

/* =========================================================
   HERO CARD (CENTRAL)
========================================================= */
var dadosDosCards = [
    {
        link: '#frutiferas',
        fotoLabel: 'Ipê-Rosa',
        imagem: 'https://images.unsplash.com/photo-1551970634-747846a548cb?w=900&q=80',
        estrelas: '★★★★★',
        titulo: 'Ipê-Rosa',
        descricao: 'Árvore nativa do Brasil com floração exuberante e importância ecológica única.'
    },
    {
        link: '#medicinais',
        fotoLabel: 'Palmeira Imperial',
        imagem: 'https://images.unsplash.com/photo-1525923838299-2312b60f6d69?w=900&q=80',
        estrelas: '★★★★☆',
        titulo: 'Palmeira Imperial',
        descricao: 'Majestosa e resistente, traz porte nobre para parques, avenidas e jardins grandes.'
    },
    {
        link: '#ornamentais',
        fotoLabel: 'Ficus Lyrata',
        imagem: 'https://images.unsplash.com/photo-1470058869958-2a77ade41c02?w=900&q=80',
        estrelas: '★★★★★',
        titulo: 'Ficus Lyrata',
        descricao: 'Folhas em forma de violino, purificadora do ar e presença marcante em interiores modernos.'
    }
];

var posicaoAtual = 0;

function mudarConteudoCard(direcao) {
    posicaoAtual += direcao;
    if (posicaoAtual < 0) posicaoAtual = dadosDosCards.length - 1;
    if (posicaoAtual >= dadosDosCards.length) posicaoAtual = 0;

    var d = dadosDosCards[posicaoAtual];
    document.getElementById('linkCardFixo').setAttribute('href', d.link);
    document.getElementById('nomeFotoFixo').textContent = d.fotoLabel;
    var img = document.getElementById('imgCardFixo');
    img.style.opacity = '0';
    setTimeout(function () {
        img.setAttribute('src', d.imagem);
        img.setAttribute('alt', d.titulo);
        img.style.opacity = '1';
    }, 150);
    document.getElementById('estrelasCardFixo').textContent = d.estrelas;
    document.getElementById('tituloCardFixo').textContent = d.titulo;
    document.getElementById('descricaoCardFixo').textContent = d.descricao;
}

/* Add fade transition to hero image */
document.addEventListener('DOMContentLoaded', function () {
    var img = document.getElementById('imgCardFixo');
    if (img) img.style.transition = 'opacity .3s';
});

/* =========================================================
   CHATBOT
========================================================= */
function alternarChat() {
    var chat = document.getElementById('chatbotPrincipal');
    var input = document.getElementById('chatbotInput');
    if (!chat) return;
    if (chat.style.display === 'flex') {
        chat.style.display = 'none';
    } else {
        chat.style.display = 'flex';
        if (input) input.focus();
    }
}

function fecharChat() {
    var chat = document.getElementById('chatbotPrincipal');
    if (chat) chat.style.display = 'none';
}

document.addEventListener('click', function (e) {
    var chat = document.getElementById('chatbotPrincipal');
    var botao = document.querySelector('.btn-abrir-chat-principal');
    if (!chat || !botao) return;
    if (chat.style.display !== 'flex') return;
    if (!chat.contains(e.target) && !botao.contains(e.target)) fecharChat();
});

function adicionarMensagem(texto, tipo) {
    var caixa = document.getElementById('chatbotMensagens');
    if (!caixa) return;
    var div = document.createElement('div');
    div.className = 'mensagem ' + tipo;
    var span = document.createElement('span');
    span.textContent = tipo === 'bot' ? 'Bot' : 'Você';
    div.appendChild(span);
    div.appendChild(document.createTextNode(texto));
    caixa.appendChild(div);
    caixa.scrollTop = caixa.scrollHeight;
}

function respostaBot(texto) {
    var m = texto.toLowerCase().trim();
    if (m.match(/^(oi|olá|ola|hey|hi)$/)) return 'Olá! 👋 Posso ajudar com informações sobre plantas, solo e sustentabilidade.';
    if (m.includes('bom dia')) return 'Bom dia! 🌿 Em que posso ajudar?';
    if (m.includes('boa tarde')) return 'Boa tarde! 🌿 Em que posso ajudar?';
    if (m.includes('boa noite')) return 'Boa noite! 🌙 Em que posso ajudar?';
    if (m.includes('ipê') || m.includes('ipe')) return 'O Ipê-Rosa (Handroanthus impetiginosus) é uma das árvores mais belas do Brasil. Floresce no inverno, transformando paisagens em tapetes rosados. 🌸';
    if (m.includes('orquídea') || m.includes('orquidea')) return 'Orquídeas são flores elegantes que amam umidade. Regue uma vez por semana e mantenha em meia sombra para floração prolongada. 🌺';
    if (m.includes('aloe') || m.includes('babosa')) return 'A Babosa (Aloe vera) tem gel cicatrizante e anti-inflamatório. Precisa de pouca água e resiste bem ao sol. 🌵';
    if (m.includes('mangueira') || m.includes('manga')) return 'A Mangueira (Mangifera indica) é tropical, ama sol pleno e solo bem drenado. Produz frutos ricos em vitaminas A, C e betacaroteno. 🥭';
    if (m.includes('planta') || m.includes('plantas')) return 'As plantas são fundamentais para o equilíbrio do ecossistema. Temos três categorias: frutíferas, medicinais e ornamentais. Qual te interessa? 🌿';
    if (m.includes('solo') || m.includes('terra')) return 'O solo saudável é a base de tudo! Rico em microrganismos, ele nutre as plantas e regula o ciclo da água. 🌱';
    if (m.includes('regar') || m.includes('água') || m.includes('agua')) return 'A frequência de rega varia por espécie. Plantas suculentas precisam de pouca água; tropicais geralmente preferem solo levemente úmido. 💧';
    if (m.includes('adubo') || m.includes('fertilizante')) return 'Adubos orgânicos como húmus e compostagem são ótimos para plantas. Aplique a cada 30–45 dias durante o período de crescimento. 🌱';
    if (m.includes('sustentab')) return 'Sustentabilidade é usar os recursos naturais de forma responsável para as gerações futuras. Plantar árvores é um ótimo começo! 🌎';
    if (m.includes('obrigad')) return 'De nada! 😊 Estou sempre aqui para ajudar.';
    if (m.includes('tchau') || m.includes('adeus')) return 'Tchau! 👋 Até a próxima. Continue cuidando das plantas!';
    return 'Ainda estou aprendendo! 🤖 Tente perguntar sobre: solo, plantas, rega, adubação, sustentabilidade ou uma espécie específica.';
}

function enviarMensagem() {
    var input = document.getElementById('chatbotInput');
    if (!input) return;
    var texto = input.value.trim();
    if (!texto) return;
    adicionarMensagem(texto, 'usuario');
    input.value = '';
    setTimeout(function () {
        adicionarMensagem(respostaBot(texto), 'bot');
    }, 500);
}

document.addEventListener('DOMContentLoaded', function () {
    var input = document.getElementById('chatbotInput');
    if (input) {
        input.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') { e.preventDefault(); enviarMensagem(); }
        });
    }
});
